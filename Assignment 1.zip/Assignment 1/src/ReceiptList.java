import java.io.*;
import java.util.ArrayList;

public class ReceiptList extends ArrayList<Receipt>{
    public ReceiptList(){
        //empty rList
    }

    public boolean importReceipt(String filepath, ProductList realList){
        File importFile = new File(filepath);
        try {
           if (importFile.exists() && importFile.isFile()){
               FileReader fr = new FileReader(filepath);
               BufferedReader br = new BufferedReader(fr);
               ProductList importedList = new ProductList();
               //for each line
               while (br.ready()){
                   String temp = br.readLine();
                   String[] rs = temp.split(" - ");
               
                   
                   if (rs.length >= 6 ){ //only runs if the read elements have a valid no of attributes
                        if (realList.isCodeDupplicated(rs[1]) && Inputter.isValidInt(rs[5], 1, 99999) ){
                            String choice;
                                do {
                                        choice = Inputter.getAlpha("Duplicate code detected for Product "+ rs[1]+" . Update existing product by quantity ("+rs[5]+")instead?(Y/N)", false).toUpperCase();
                                        System.out.println(choice);
                                } while (!choice.equals("Y") && !choice.equals("N"));

                                //Changes quantity based on code
                                if (choice.equals("Y")) realList.searchProduct(rs[1]).setQuantity(realList.searchProduct(rs[1]).getQuantity() + Integer.parseInt(rs[5]));
                        }
                        //Name - Code - Manufacturing Date - Expiration Date - Type - Quantity - Status
                        //Product p = new Product(rs[0],rs[1],rs[2],rs[3],Integer.parseInt(rs[4]),Integer.parseInt(rs[5]),1);
                        //check for legible product attributes
                        else if (Inputter.isValidAlpha(rs[0]) && !realList.isCodeDupplicated(rs[1]) && Inputter.isValidDatePair(rs[2], rs[3]) && Inputter.isValidInt(rs[4],0, 1) && Inputter.isValidInt(rs[5], 1, 99999) ){
                                Product p = new Product(rs[0],rs[1],rs[2],rs[3],Integer.parseInt(rs[4]),Integer.parseInt(rs[5]),1);
                                importedList.add(p); //Adds product info to receipt list
                                Product realProduct = new Product(p);
                                realList.add(realProduct);//Adds the instance to the real productlist

                        } //else System.out.println(Inputter.isValidAlpha(rs[0]) +""+  importedList.isCodeDupplicated(rs[1]) +""+ Inputter.isValidDatePair(rs[2], rs[3]) +""+ Inputter.isValidInt(rs[4],0, 1) +""+ Inputter.isValidInt(rs[5], 0, 99999));
                   }    
               }
               br.close(); 
               if (importedList.isEmpty()) {
                 System.out.println("All files have duplicate code or invalid attributes. Import Terminated.");
                 return false;
               }
               this.createReciept(importedList, "IMPORT");
               //when finished creating, goes back to warehouse
               System.out.println("Import Sucessful.");
               return true;
               
           } else throw new IOException();
     
       } catch (IOException e) {
             System.out.println("File not Found.");
             return false;
       }
   
   }

   public boolean exportReceipt(ProductList realList){
        String choice = "Y";
   
        if (realList.isEmpty()) {
            System.out.println("Nothing to export.");
            return false;
        }

        ProductList exProductList = new ProductList();


        while (choice.equals("Y")){
          
            int eQuantity;
            System.out.println("Available products: ");
            for (Product product: realList){
                System.out.println(product.toString());
            }
            String eCode = Inputter.getCode("Enter Product Code for Export: ",null);
            Product refProduct = realList.searchProduct(eCode);
            //creates an instance of the referenced product, which will change depending on the quantity set
            Product eProduct = new Product(refProduct);
            
            if (refProduct==null || refProduct.getQuantity() == 0) {
                System.out.println("Cannot Export, product does not exist");
                break;
            }

            System.out.println("Found. Product info: "+ refProduct.toString());
            eQuantity = Inputter.getInt("Input valid quantity to import: ", 1,refProduct.getQuantity(),false);
            //change the values of the productlist item but does not delete
            //changes value of the product that is pointed to
            refProduct.setQuantity(refProduct.getQuantity() - eQuantity);   
            eProduct.setQuantity(eQuantity);

            System.out.printf("Stock changed to: %d%n", refProduct.getQuantity());
            exProductList.add(eProduct);

            do {
                choice = Inputter.getAlpha("Want to add more products?(Y/N) ", false).toUpperCase();
            } while (!choice.equals("Y") && !choice.equals("N"));

            //when the productlist is empty and user stills wants to continue:
            if (realList.isEmpty() && choice.equals("Y")) {
                choice = "N";
                System.out.println("Nothing else to export");
            }
        } // end of while loop

        if (exProductList.isEmpty()) return false;
        
        //creates newexportfile
        exProductList.dataStorage("export"+ codeGeneration() +".dat");

        System.out.println("New Export Data Created.");

        this.createReciept(exProductList, "EXPORT");

        //when finished creating, goes back to warehouse
        System.out.println("Export sucessful.");


        //Export to excel Spreadsheet
   
        //
        return true;

    }

    private int codeGeneration(){
    //its empty
    return this.size() + 1; 
   }

   public void createReciept(ProductList p,String field){
        
        long startTime = System.nanoTime();
        
        Receipt newReceipt = new Receipt();
        newReceipt.setCode(codeGeneration());
        newReceipt.setField(field);
        newReceipt.setpList(p);

        long endTime = System.nanoTime();
        //returns creation time
        long time = endTime - startTime;
        newReceipt.setCreateTime(time);
        this.add(newReceipt);

        System.out.println("New Receipt created in " + time+" nanoseconds.");
   }    

   public boolean updateReceipt(Product uProduct){
    //goes through each productlist in each receipt and changes the corresponding values
        if (this.isEmpty()){
            System.out.println("No receipts lists to be updated.");
            return false;
        }
        for (Receipt receipt : this){
            //searches the each reciept list for the product to update find index of the element to be updated in receipt 
            int uIndex = receipt.getpList().indexOf(receipt.getpList().searchProduct(uProduct.getCode()));
            if (uIndex != -1){
                //use the index to find the value to update
                receipt.getpList().get(uIndex).setName(uProduct.getName());
                receipt.getpList().get(uIndex).setManudate(uProduct.getManudate());
                receipt.getpList().get(uIndex).setExpdate(uProduct.getExpdate());
                receipt.getpList().get(uIndex).setType(uProduct.getType());
                receipt.getpList().get(uIndex).setStatus(uProduct.getStatus());
            }
        }
        System.out.println("Receipt list has been updated.");
        return true;
   }

   public boolean receiptStorage(String filePath){
    try {
        //writes new data into file
        FileWriter fileWriter = new FileWriter(filePath);
        // Create a BufferedWriter to write efficiently
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
       
        for (Receipt receipt : this){
            bufferedWriter.write(receipt.toString());
            bufferedWriter.newLine();
            bufferedWriter.write("Name - Code - Manufacturing Date - Expiration Date - Type (1. Daily Use | 2. Long Shelf) - Quantity - Status");
            bufferedWriter.newLine();
            for (Product product : receipt.getpList()){
                bufferedWriter.write(product.toString());
                bufferedWriter.newLine();
            }
            bufferedWriter.newLine();
        }

        bufferedWriter.close();
    } catch (IOException e){
        e.printStackTrace();
        return false;
    }

    return true;
}


}



