import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Collections;


public class Report implements IReport {

    public boolean expiredProducts(ProductList realList){
        if(realList.isEmpty()) {
            System.out.println("Product list is empty.");
            return false;
        }
        int expired = 0;
        System.out.print("Expired Products: \nCode - Name - Manufacturing Date - Expiration Date - Quantity\n");
        for (Product product :realList){

            SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyy");
            Date currentDate = new Date();
            String dateString = sdf.format(currentDate);

            if (Inputter.isValidDatePair(product.getExpdate(),dateString )){
                System.out.println(product.getCode() +" - "+ product.getName()+" - "+product.getManudate()+" - "+product.getExpdate()+" - "+product.getQuantity());
                expired++;
            }
        }
        if (expired==0) System.out.println("No products are expired.");
        return true;
    }

    public boolean sellingProducts(ProductList realList){
        if(realList.isEmpty()) {
            System.out.println("Product list is empty.");
            return false;
        }

        int selling = 0;
        System.out.print("Selling Products: \nCode - Name - Manufacturing Date - Expiration Date - Quantity\n");
        for (Product product :realList){

            SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyy");
            Date currentDate = new Date();
            String dateString = sdf.format(currentDate);

            if (!Inputter.isValidDatePair(product.getExpdate(),dateString )){
                System.out.println(product.getCode() +" - "+ product.getName()+" - "+product.getManudate()+" - "+product.getExpdate()+" - "+product.getQuantity());
                selling++;
            }
        }
        if (selling==0) System.out.println("No products are avavilable for selling.");
        return true;

    }


    public boolean stockStatus(ProductList realList){
        if(realList.isEmpty()) {
            System.out.println("Product list is empty.");
            return false;
        }

        ProductList outOfStock = new ProductList();


        System.out.println("Products which are low on stock: \nCode - Name - Manufacturing Date - Expiration Date - Quantity ");
        for (Product product : realList){
            if (product.getQuantity()<=3){
                outOfStock.add(product);
            }
        }
        if (outOfStock.isEmpty()) {
            System.out.println("All items are in stock.");
            return true;
        }

        Collections.sort(outOfStock);
        for (Product product : outOfStock){
            System.out.println(product.getCode() +" - "+ product.getName()+" - "+product.getManudate()+" - "+product.getExpdate()+" - "+product.getQuantity());
        }
        return true;
    }


    public boolean imexSearch(ReceiptList receiptList,ProductList pList){
        if(receiptList.isEmpty()) {
            System.out.println("Receipt list is empty \u00AF\\_(\u30C4)_/\u00AF.");
            return false;
        }
        String xCode;
        Product xProduct = null;

   
        xCode = Inputter.getCode("Enter Search Code: ",pList);
        for (Receipt receipt : receiptList){
            xProduct = receipt.getpList().searchProduct(xCode);
            //returns a product not equal to null if product is found
            if (xProduct != null){
                System.out.println("Product found in "+ receipt.getField()+ " RECEIPT " +receipt.getCode()+"\nName - Code - Manufacturing Date - Type - Expiration Date - Quantity - Status");             
                System.out.println(xProduct.toString());
            }
        }
        if (xProduct == null){
            System.out.println("Product " + xCode  +" does not exist.");
        }
        return true;
     

    }
}
