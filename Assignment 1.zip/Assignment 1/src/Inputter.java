import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Inputter {
    static Scanner sc = new Scanner(System.in);

    // Get an integer between min... max
    public static int getInt(String msg,int start,int end,boolean isUpdate){
        System.out.print(msg);
        int input = 1;
        String checkBlank="";
        boolean validInput = false;
        while (!validInput) {
            validInput = false;
            try{
                checkBlank = sc.nextLine();
                if (isUpdate && checkBlank.isBlank()) return -1;
                                
                input = Integer.parseInt(checkBlank);
                if (input < start || input > end) throw new NumberFormatException();
                validInput = true;                
            // Catches input mismatch exception
            } catch (NumberFormatException e){
                System.out.println("Invalid input. Please enter a valid integer within "+start+" and "+end);
                System.out.print(msg);
            }
       }
       //returns user input
       return input; 
    }

    public static boolean isValidInt(String n,int start,int end){
        int realN;
        try {
            realN = Integer.parseInt(n);
        } catch (NumberFormatException e){
            return false;
        } 
        //return boolean values by which n would be valid
        return realN >= start && realN <= end && !n.isBlank(); 
    }

    public static String getCode(String msg, ProductList codeList){
        String input = "";
        boolean validInput = false;
        if (codeList != null){
            System.out.print("Available Codes: ");
            for (Product product : codeList){
                System.out.print(product.getCode()+", ");
            }
        }   
        System.out.print(msg);
         
        while (!validInput) {
            input = sc.nextLine().trim();
            if (!input.isEmpty()) {
                validInput = true;
            } else {
                System.out.println("Invalid input. PLease enter a valid value.");
                System.out.print(msg);
            }
        }
       //returns user input
       return input; 
    }

    
    public static String getCode(String msg,int n){
        String input = "";
        boolean validInput = false;
         System.out.print(msg);
        while (!validInput) {
            input = sc.nextLine().trim();
            if (input.matches("^[\\d]{" + n + ",}$")) {
                validInput = true;
            } else {
                System.out.println("Invalid input. PLease enter a valid value.");
                System.out.print(msg);
            }
        }
       //returns user input
       return input; 
    }


    public static String getAlpha(String msg,boolean isUpdate){
        System.out.print(msg);
        String input = "";
        boolean validInput = false;
        while (!validInput) {
            input = sc.nextLine().trim();
            //checks if condition is set to accept blank space
            if (isUpdate && input.equals("")) return input;           
            //checks if input matches condition fo only alphabetical chars
            else if (input.matches("^[a-zA-Z\\s]+$")) {
                validInput = true;             
            } else {
                System.out.println("Invalid input. Please enter alphabetical characters only.");
                System.out.print(msg);
            }
        }
       //returns user input
       return input; 
    }

    public static boolean isValidAlpha(String word){
        return word.matches("^[a-zA-Z\\s]+$");
    }


    public static String getDate(String msg,boolean isUpdate){
        System.out.print(msg);
        String checkBlank = "";
        Date date;
        boolean validInput = false;
        while (!validInput) {
            validInput = false;
            try{
                checkBlank = sc.nextLine();
                if (isUpdate && checkBlank.isBlank()) return "";
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");  
                sdf.setLenient(false); // Disable lenient parsing (strict mode)
                date = sdf.parse(checkBlank);
                checkBlank = sdf.format(date);
                validInput = true;
            } catch (java.text.ParseException e){
                 System.out.println("Invalid input. Please enter valid date.");
                 System.out.print(msg);
            }
        }
       //returns user input
       return checkBlank; 
    }
    

    public static boolean isValidDatePair(String manu,String exp){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date manuDate = sdf.parse(manu);
            Date expDate = sdf.parse(exp);
            sdf.setLenient(false); // Disable lenient parsing (strict mode)
            
            //returns whether it is valid or not
            return !manuDate.after(expDate);
        } catch (java.text.ParseException e){
            return false;
        }
    }
}
