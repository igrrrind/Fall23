import java.util.ArrayList;
import java.io.*;

public class ProductList extends ArrayList<Product>{
    public ProductList(){
        //constructor for creating empty list
    }
        //returns product index for updating in dat file and in productlist
    public Product searchProduct(String code){
        code = code.trim().toUpperCase();
        for (int i = 0; i < this.size();i++){
            if (this.get(i).getCode().toUpperCase().equals(code)){
                return this.get(i);
            }
        }
        return null;
    }

    public boolean isCodeDupplicated (String code) {
        code = code.trim().toUpperCase () ;
        return searchProduct(code)!=null;
    }    

//---------------------------------------------------------------------------------------------------------------

    //ADD PRODUCT
    public boolean addProduct(){
        
        Product newProduct = new Product();

        newProduct.setName(Inputter.getAlpha("Enter Name: ",false));
        
        do {
            newProduct.setCode(Inputter.getCode("Enter Code: ",null).toUpperCase());
            if (isCodeDupplicated(newProduct.getCode())) System.out.println("Enter a Valid Non-Duplicate Code");
        
        } while (isCodeDupplicated(newProduct.getCode()));
    
        do {
            newProduct.setManudate(Inputter.getDate("Enter Manufacturing Date: (dd/mm/yyyy)", false));

            newProduct.setExpdate(Inputter.getDate("Enter Expiry Date: (dd/mm/yyyy)", false));
            if (!Inputter.isValidDatePair(newProduct.getManudate(), newProduct.getExpdate())) System.out.println("Invalid dates, please input again."); 
        
        } while (!Inputter.isValidDatePair(newProduct.getManudate(), newProduct.getExpdate()));

        newProduct.setType(Inputter.getInt("Enter Type (1. Daily Use | 2. Long Shelf): ",1,2,false));
        
        newProduct.setQuantity(Inputter.getInt("Enter Quantity: ",1,99999,false));       
                
        System.out.print("Status set to 0 for unimported. ");
        
        this.add(newProduct);
        return true;   
    }

//---------------------------------------------------------------------------------------------------------------

    //update product to product list 
    public Product updateProduct(){
        if(this.isEmpty()) {
            System.out.println("Product list is empty \u00AF\\_(\u30C4)_/\u00AF. No Updates can be made.");
            return null;
        }
        String uCode;
        Product product;
        Product uProduct = new Product();

        do {
            uCode = Inputter.getCode("Enter Search Code: ",this);
            product = searchProduct(uCode);
            if (product == null){
                System.out.println("Product " + uCode +" does not exist. Please try again.");
            }
        } while(product == null);
        System.out.println("Product found: "+product.toString());
        System.out.println("Leave blank to keep old values.");

        //automatically sets code
        uProduct.setCode(product.getCode());

        uProduct.setName(Inputter.getAlpha("Set new name: ",true));
        if (uProduct.getName().isBlank()) uProduct.setName(product.getName());


        //Set valid dates
        do {
            uProduct.setManudate(Inputter.getDate("Set new manufacturing date: ",true));
            if (uProduct.getManudate().isBlank()) uProduct.setManudate(product.getManudate());

            uProduct.setExpdate(Inputter.getDate("Set new expiry date: ",true));
            if (uProduct.getExpdate().isBlank()) uProduct.setExpdate(product.getExpdate());

            if (!Inputter.isValidDatePair(uProduct.getManudate(), uProduct.getExpdate())) System.out.println("Invalid dates, please input again.");

        } while (!Inputter.isValidDatePair(uProduct.getManudate(), uProduct.getExpdate()));

        uProduct.setType(Inputter.getInt("Set new type (1. Daily Use | 2. Long Shelf): ",1,2,true));
        if (uProduct.getType() == -1) uProduct.setType(product.getType());

        uProduct.setQuantity(Inputter.getInt("Set new quantity: ",1,99999,true));
        if (uProduct.getQuantity() == -1) uProduct.setQuantity(product.getQuantity());

        uProduct.setStatus(Inputter.getInt("Set new status (0. Unimported, 1. Imported): ",0,1,true));
        if (uProduct.getStatus() == -1) uProduct.setStatus(product.getStatus());

        System.out.println(uProduct.toString());

        this.set(this.indexOf(product),uProduct);

        System.out.println("Product "+uCode+" has been updated to the list.");
        searchProduct(uCode).toString();
                
        return uProduct;
    }

//---------------------------------------------------------------------------------------------------------------

    //Shows productlist
    public void showProducts(){
        if(this.isEmpty()) {
            System.out.println("Product list is empty. Nothing to show \u00AF\\_(\u30C4)_/\u00AF.");
            return;
        }
        System.out.println("Storage Information: \nName - Code - Manufacturing Date - Expiration Date - Type (1. Daily Use | 2. Long Shelf) - Quantity - Status");

        for (Product sProduct:this){
            System.out.println(sProduct.toString());
        }
    }


//---------------------------------------------------------------------------------------------------------------

    public boolean deleteProduct(){

        if (this.isEmpty()) {
            System.out.println("There is nothing to delete \u00AF\\(\u30C4)/\u00AF");
            return false;
        } 
        String dCode;
        Product dProduct;
        do {
            dCode = Inputter.getCode("Enter Search Code: ",this);
            dProduct = searchProduct(dCode);
            if (dProduct == null){
                System.out.println("Product " + dCode +" does not exist \u00AF\\(\u30C4)/\u00AF. Please try again.");
            }
        } while(dProduct == null);


        //Asks if user wants to delete
        do {
            dCode = Inputter.getAlpha("Are you sure you want to delete?(Y/N) ", false).toUpperCase();
        } while (!dCode.equals("Y") && !dCode.equals("N"));
        if (dCode.equals("N")) return false;

        if (dProduct.getStatus()==0) {
            this.remove(dProduct);
            System.out.println("Removal Success.");
            return true;
        } else {
            System.out.println("This product has been imported. Deletion is not allowed.");
            return false;
        }        
    }
//---------------------------------------------------------------------------------------------------------------



    public boolean dataStorage(String filePath){
        try {
            //writes new data into file
            FileWriter fileWriter = new FileWriter(filePath);
            // Create a BufferedWriter to write efficiently
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write("Name - Code - Manufacturing Date - Expiration Date - Type (1. Daily Use | 2. Long Shelf) - Quantity - Status");
            bufferedWriter.newLine();
           
            for (Product uProduct : this){
                bufferedWriter.write(uProduct.toString());
                bufferedWriter.newLine();
            }
            bufferedWriter.close();
        } catch (IOException e){
            e.printStackTrace();
            return false;
        }

        return true;
    }

}
