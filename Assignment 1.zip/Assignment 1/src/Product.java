import java.util.*;

public class Product implements Comparable<Product>{
    private String name;
    private String code;
    private String manudate;
    private String expdate;
    private int type; //1 for food, 0 for drink
    private int quantity;
    private int status;//1 for imported 0 for not imported
    
    //constructor
    public Product(String name, String code, String manudate, String expdate, int type, int quantity, int status) {
        this.name = name;
        this.code = code;
        this.manudate = manudate;
        this.expdate = expdate;
        this.type = type;
        this.quantity = quantity;
        this.status = status;
    }
    //copy constructor
    public Product(Product otherProduct) {
        this.name = otherProduct.name;
        this.code = otherProduct.code;
        this.manudate = otherProduct.manudate;
        this.expdate = otherProduct.expdate;
        this.type = otherProduct.type;
        this.quantity = otherProduct.quantity;
        this.status = otherProduct.status;
    }


    public Product(){}

    // GETTERS AND SETTERS
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getManudate() {
        return manudate;
    }
    public void setManudate(String manudate) {
        this.manudate = manudate;
    }
    public String getExpdate() {
        return expdate;
    }
    public void setExpdate(String expdate) {
        this.expdate = expdate;
    }
    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }    

    @Override
    public String toString(){
        return  name+" - "+code+" - "+manudate+" - "+expdate+" - "+type+" - "+quantity+" - "+status;
    }

    @Override 
    public int compareTo(Product otherPerson){
        return Integer.compare(this.quantity,otherPerson.quantity);

    }
}
