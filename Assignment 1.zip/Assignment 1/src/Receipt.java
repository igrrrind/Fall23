public class Receipt {
    private int code;
    private String field; //import or export
    private long createTime;
    private ProductList pList;

    public Receipt() {
    }
    
    public Receipt(int code, String field, long createTime, ProductList pList) {
        this.code = code;
        this.field = field;
        this.createTime = createTime;
        this.pList = pList;
    }



    //GETTERS AND SETTERS
    public int getCode() {
        return code;
    }
    public void setCode(int code) {
        this.code = code;
    }
    public String getField() {
        return field;
    }
    public void setField(String field) {
        this.field = field;
    }
    public long getCreateTime() {
        return createTime;
    }
    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }
    public ProductList getpList() {
        return pList;
    }
    public void setpList(ProductList pList) {
        this.pList = pList;
    }

    @Override
    public String toString(){
        String codeModifier = "";

        if (code < 10) codeModifier = "000000";
        else if (code < 100) codeModifier = "00000";
        else if (code < 1000) codeModifier = "0000";
        else if (code < 10000) codeModifier = "000";
        else if (code < 100000) codeModifier = "00";
        else if (code < 1000000) codeModifier = "0";
        
        return field.toUpperCase() + " RECEIPT " + codeModifier+ code + " ----- Created in "+createTime+" nanoseconds.";
    }

    
}
