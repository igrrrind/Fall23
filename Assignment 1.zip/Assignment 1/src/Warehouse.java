import java.util.Scanner;

public class Warehouse {
    public static void main(String[] args) {
        //defining options menu, submenus
        String[] options = {"Manage Products ","Manage Warehouse ","Report","Store Data","Quit"};
        String[] productOptions = {"Add a Product ","Update Information ","Delete Product","Show All Product","Back to Main Menu"};
        String[] warehouseOptions = {"Create an Import Receipt ","Create an Export Receipt","Back to Main Menu"};
        String[] reportOptions = {"Products that have expired ","Products that the store is selling","Products that are running out of stock (sorted in ascending order)","Receipt search by product","Back to Main Menu"};
        
        int choice = 1;
        
        Scanner sc = new Scanner(System.in);
        ProductList pdList = new ProductList();
        ReceiptList rcList = new ReceiptList();
        Report report = new Report();
        String filePath;

        
        do {
            //MAIN MENU
            subMenu(options,"\n------STORE MANAGEMENT SYSTEM------");
            choice = Inputter.getInt("",1,5,false);
            switch (choice) {
                
                case 1:
                //PRODUCT MANAGEMENT
                    do{
                        subMenu(productOptions,"\n------Manage Products------");
                        choice = Inputter.getInt("",1,5,false);
                        
                        switch (choice){
                            //add product
                            case 1:
                                //Confirms product being added
                                if (pdList.addProduct()) {
                                    System.out.println("Product added.");
                                } else {
                                    System.out.println("Unsuccessful.");
                                }
                                choice = Inputter.getInt("Continue manging products?\n0.No\n1.Yes\n> ",0,1,false); 
                                
                                if (choice == 0 )choice = 5;
                                break;
                            

                            //Allows User to make chanegs to existing products, and then updating the receipts based on the new change
                            case 2: rcList.updateReceipt(pdList.updateProduct()); break;

                            case 3: pdList.deleteProduct();break;
                            
                            //show products
                            case 4:
                                pdList.showProducts();
                                break;

                            case 5:
                                break;

                            default:
                                System.out.println("Please input valid numbers.\n");


                        }
                    } while (choice !=5); 
                    choice = -1;
                    //Loops submenu when there is an invalid input
                    break;
                
                    //MANAGE WAREHOUSE
                case 2:
                    subMenu(warehouseOptions,"\n------Manage Warehouse------");
                    choice = Inputter.getInt("",1,3,false);
                    switch(choice){

                        case 1:   
                            String flag = "N";
                            do {      
                                System.out.print("Enter file path (Leave blank to cancel process): ");                   
                                filePath = sc.nextLine();
                                if (filePath.isEmpty()) break;
                                else if (rcList.importReceipt(filePath,pdList)){
                                    do {
                                        flag = Inputter.getAlpha("Want to continue importing?(Y/N) ", false).toUpperCase();
                                    } while (!flag.equals("Y") && !flag.equals("N"));
                                }
                                //break out of loop if the boolean is false
                            } while (flag.equals("Y"));
                        
                            break;

                        case 2:
                            rcList.exportReceipt(pdList);
                            break;

                        case 3: break;
                            
                        default:
                    }
                    break;


                    //REPORT
                case 3:
                    subMenu(reportOptions,"\n------Generate Report------");
                    choice = Inputter.getInt("",1,5,false);
                    switch(choice){


                        //List out products which have expired
                        case 1:    report.expiredProducts(pdList); break;

                        //List out products which are selling
                        case 2: report.sellingProducts(pdList); break;

                        //List out products which are running out of stock
                        case 3: report.stockStatus(pdList); break;
                        
                        //List out receipts which contain the code of the specified product
                        case 4: report.imexSearch(rcList,pdList); break;

                        case 5: choice = -1; break; 
                        
                        default:
                    }

                    break;

                    //STORE         
                case 4:
                    if (pdList.dataStorage("products.dat")) {
                            System.out.println("Data storage successful.");
                    } else System.out.println("Data storage failed.");
                    //Store receipt data
                    if (rcList.receiptStorage("warehouse.dat")) {
                            System.out.println("Receipt storage successful.");
                    } else System.out.println("Receipt storage failed.");
                    break;

                    //QUIT                
                case 5:
                    System.out.println("Thank you for using our CMS, please leave a good review.");
                    break;

                default:
                    System.out.println("Please input valid numbers.\n");
            }

        } while (choice != 5);
        sc.close();
    }
  
    public static void subMenu(String[] options,String msg){
        System.out.println(msg);
        for (int i = 0;i < options.length;i++){
            System.out.println(i+1+". "+options[i]);
        }
        System.out.print("Choose from 1 to "+options.length+": "); 
    }
}
