public interface IReport {
    
    public abstract boolean expiredProducts(ProductList reaList);

    public abstract boolean sellingProducts(ProductList reaList);
    
    public abstract boolean stockStatus(ProductList reaList);
    
    public abstract boolean imexSearch(ReceiptList receiptList,ProductList pList);
}
